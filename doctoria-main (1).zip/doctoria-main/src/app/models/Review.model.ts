export interface Review{
  _id?: string;
  rate: number;
  comment: string;
  createdAt?: Date;
}
