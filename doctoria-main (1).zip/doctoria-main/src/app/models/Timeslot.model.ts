export interface Timeslot{
  _id?: string;
  days:string[];
  slots:string[];
}
