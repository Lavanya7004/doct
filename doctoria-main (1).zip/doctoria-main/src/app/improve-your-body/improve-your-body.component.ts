import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-improve-your-body',
  templateUrl: './improve-your-body.component.html',
  styleUrls: ['./improve-your-body.component.css']
})
export class ImproveYourBodyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
