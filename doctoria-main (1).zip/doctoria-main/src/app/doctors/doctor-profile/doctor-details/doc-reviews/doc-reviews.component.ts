import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doc-reviews',
  templateUrl: './doc-reviews.component.html',
  styleUrls: ['./doc-reviews.component.css']
})
export class DocReviewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
